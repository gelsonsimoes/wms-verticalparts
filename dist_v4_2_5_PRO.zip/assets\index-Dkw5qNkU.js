import{a6 as r}from"./index-BMEjd-r1.js";var o=r();export{o as r};
