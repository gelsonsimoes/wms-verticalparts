import{a8 as r}from"./index-asX9r22w.js";var o=r();export{o as r};
