import{t,i as c}from"./index-asX9r22w.js";function n(...r){return t(c(r))}export{n as c};
