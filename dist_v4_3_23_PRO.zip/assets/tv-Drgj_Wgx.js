import{p as t}from"./index-asX9r22w.js";const e=[["path",{d:"m17 2-5 5-5-5",key:"16satq"}],["rect",{width:"20",height:"15",x:"2",y:"7",rx:"2",key:"1e6viu"}]],c=t("tv",e);export{c as T};
