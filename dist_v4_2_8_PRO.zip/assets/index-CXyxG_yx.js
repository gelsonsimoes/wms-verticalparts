import{a6 as r}from"./index-CCsx6vvn.js";var o=r();export{o as r};
