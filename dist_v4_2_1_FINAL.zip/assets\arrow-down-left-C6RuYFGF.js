import{m as o}from"./index-B1BSRn0M.js";const t=[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]],r=o("arrow-down-left",t);export{r as A};
