import{a6 as r}from"./index-B1BSRn0M.js";var o=r();export{o as r};
