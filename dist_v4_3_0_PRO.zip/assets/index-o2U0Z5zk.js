import{a6 as r}from"./index-Bgt664H3.js";var o=r();export{o as r};
