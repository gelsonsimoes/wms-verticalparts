import{a6 as r}from"./index-Dsc7lSXK.js";var o=r();export{o as r};
