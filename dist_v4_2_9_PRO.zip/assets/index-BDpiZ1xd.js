import{a6 as r}from"./index-DFDuHDSj.js";var o=r();export{o as r};
