import{a6 as r}from"./index-BeR6O_ee.js";var o=r();export{o as r};
